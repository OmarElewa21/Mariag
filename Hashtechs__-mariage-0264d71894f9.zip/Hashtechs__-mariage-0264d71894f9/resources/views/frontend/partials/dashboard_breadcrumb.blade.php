 <div class="section-header">
            <h1>{{__($pageTitle)}}</h1>
          </div>