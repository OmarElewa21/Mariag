<aside id="sidebar-wrapper">
          <div class="sidebar-brand">
            <a href="<?php echo e(route('user.dashboard')); ?>"><?php echo e(__(@$general->sitename)); ?></a>
          </div>
          <ul class="sidebar-menu">
              <li class="nav-item dropdown <?php echo e(activeMenu('user.dashboard')); ?>">
                <a href="<?php echo e(route('user.dashboard')); ?>" class="nav-link"><i class="fas fa-home"></i><span><?php echo e($navbar['Dashboard']); ?></span></a>
              </li>

              <?php if(auth()->user()->user_type == 2): ?>
              <li class="nav-item dropdown <?php echo e(activeMenu('user.service*')); ?>">
                <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-toilet-paper"></i> <span><?php echo e($navbar['Service']); ?></span></a>
                <ul class="dropdown-menu">
                  <li><a class="nav-link" href="<?php echo e(route('user.service')); ?>"><?php echo e($navbar['All Services']); ?></a></li>
                  <li><a class="nav-link" href="<?php echo e(route('user.service.create')); ?>"><?php echo e($navbar['Create Service']); ?></a></li>
                  <li><a class="nav-link" href="<?php echo e(route('user.service.schedule')); ?>"><?php echo e($navbar['Service Schedule']); ?></a></li>
                </ul>
              </li>

              <li class="nav-item dropdown <?php echo e(activeMenu('user.provider.booking*')); ?>">
                <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-luggage-cart"></i> <span><?php echo e($navbar['Bookings']); ?></span></a>
                <ul class="dropdown-menu">
                  <li><a class="nav-link" href="<?php echo e(route('user.provider.booking')); ?>"><?php echo e($navbar['All Bookings']); ?></a></li>
                </ul>
              </li>

              <li class="nav-item dropdown <?php echo e(activeMenu('user.plans')); ?>">
                <a href="<?php echo e(route('user.plans')); ?>" class="nav-link"><i class="fas fa-id-card-alt"></i></i><span><?php echo e($navbar['Plans']); ?></span></a>
              </li>
              
              <li class="nav-item dropdown <?php echo e(activeMenu('user.withdraw*')); ?>">
                <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="far fa-credit-card"></i> <span><?php echo e($navbar['Withdraw']); ?></span></a>
                <ul class="dropdown-menu">
                  <li><a href="<?php echo e(route('user.withdraw')); ?>" class="nav-link"><?php echo e($navbar['Withdraw Money']); ?></a></li>
                  <li><a href="<?php echo e(route('user.withdraw.all')); ?>" class="nav-link"><?php echo e($navbar['All Withdraw Log']); ?></a></li>
                  <li><a href="<?php echo e(route('user.withdraw.pending')); ?>" class="nav-link"><?php echo e($navbar['Pending Withdraw']); ?></a></li>
                </ul>
              </li>

              <?php else: ?>

              <li class="nav-item dropdown <?php echo e(activeMenu('user.bookings*')); ?>">
                <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-luggage-cart"></i> <span><?php echo e($navbar['Bookings']); ?></span></a>
                <ul class="dropdown-menu">
                  <li><a class="nav-link" href="<?php echo e(route('user.bookings')); ?>"><?php echo e($navbar['All Bookings']); ?></a></li>
                </ul>
              </li>
              <?php endif; ?>

              <li class="nav-item dropdown <?php echo e(activeMenu('user.transaction')); ?>">
                <a href="<?php echo e(route('user.transaction')); ?>" class="nav-link"><i class="fas fa-credit-card"></i><span><?php echo e($navbar['Transaction']); ?></span></a>
              </li>
            
          </ul>
        </aside><?php /**PATH C:\xampp\htdocs\mariage\resources\views/frontend/partials/side_bar.blade.php ENDPATH**/ ?>