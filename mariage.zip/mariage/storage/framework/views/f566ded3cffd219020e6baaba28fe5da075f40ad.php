 <nav class="navbar navbar-expand-lg main-navbar">

     <ul class="navbar-nav mr-auto icon-menu">
         <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="fas fa-bars"></i></a></li>
     </ul>

     <ul class="navbar-nav navbar-right">
     
         <li>
             <a target="_blank" href="<?php echo e(route('home')); ?>" class="nav-link nav-link-lg"><i class="fas fa-home mr-1"></i><span>Visit Frontend</span></a>
         </li>

         <li class="dropdown"><a href="#" data-toggle="dropdown"
                 class="nav-link dropdown-toggle nav-link-lg nav-link-user">
                 <img alt="image" src="<?php if(auth()->user()->image): ?> <?php echo e(getFile('user', auth()->user()->image)); ?> <?php else: ?> <?php echo e(getFile('logo', $general->default_image)); ?> <?php endif; ?>" class="rounded-circle mr-1">
                 <div class="d-sm-none d-lg-inline-block"><?php echo e(auth()->user()->username); ?></div>
             </a>
             <div class="dropdown-menu dropdown-menu-right">
                 <a href="<?php echo e(route('user.profile')); ?>" class="dropdown-item has-icon">
                     <i class="fas fa-user"></i> Profile
                 </a>
                 <a href="<?php echo e(route('user.change.password')); ?>" class="dropdown-item has-icon">
                     <i class="fas fa-key"></i> Change Password
                 </a>
                 <div class="dropdown-divider"></div>
                 <a href="<?php echo e(route('user.logout')); ?>" class="dropdown-item has-icon text-danger">
                     <i class="fas fa-sign-out-alt"></i> Logout
                 </a>
             </div>
         </li>
     </ul>
 </nav>
<?php /**PATH C:\xampp\htdocs\mariage\resources\views/frontend/partials/top_bar.blade.php ENDPATH**/ ?>