<div class="about-style1 pt_50 pb_50">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
              @php 
              echo clean(@$page->custom_section_data)
              @endphp
            </div>
        </div>
    </div>
</div>